using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.Test_OleDb.Source.DL
{
    public class PersonelDL : BaseDL
    {
        public PersonelDL()
            : base()
        {
        }
    }
}
