namespace Net.FreeORM.Test_OleDb.Source.QO
{
    /* Query Object Class */
    public class Crud
    {
    }
}
