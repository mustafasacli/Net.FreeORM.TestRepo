namespace Net.FreeORM.Test_Odbc.Source.QO
{
	/* Query Object Class */
	public class Crud
	{
	}
}
