using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.Test_Odbc.Source.DL
{
	public class t_UnitTypesDL : BaseDL
	{
		public t_UnitTypesDL()
			: base()
		{
		}
	}
}
