using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.Test_Odbc.Source.DL
{
	public class DeviceBedAssignmentDL : BaseDL
	{
		public DeviceBedAssignmentDL()
			: base()
		{
		}
	}
}
