using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.Test_Odbc.Source.DL
{
	public class t_BloodGroupsDL : BaseDL
	{
		public t_BloodGroupsDL()
			: base()
		{
		}
	}
}
