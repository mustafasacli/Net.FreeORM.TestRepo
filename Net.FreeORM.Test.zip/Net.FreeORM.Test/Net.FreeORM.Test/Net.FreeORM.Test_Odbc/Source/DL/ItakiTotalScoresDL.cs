using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.Test_Odbc.Source.DL
{
	public class ItakiTotalScoresDL : BaseDL
	{
		public ItakiTotalScoresDL()
			: base()
		{
		}
	}
}
