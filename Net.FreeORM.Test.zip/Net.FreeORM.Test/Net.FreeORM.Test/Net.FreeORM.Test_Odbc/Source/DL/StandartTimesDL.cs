using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.Test_Odbc.Source.DL
{
	public class StandartTimesDL : BaseDL
	{
		public StandartTimesDL()
			: base()
		{
		}
	}
}
