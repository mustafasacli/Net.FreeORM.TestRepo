namespace Net.FreeORM.ZzzTest_WFA2.Source.QO
{
	/* Query Object Class */
	public class Crud
	{
	}
}
