using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.ZzzTest_WFA2.Source.DL
{
	public class WorkStateDL : BaseDL
	{
		public WorkStateDL()
			: base()
		{
		}
	}
}
