using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.ZzzTest_WFA2.Source.DL
{
	public class CourseTypesDL : BaseDL
	{
		public CourseTypesDL()
			: base()
		{
		}
	}
}
