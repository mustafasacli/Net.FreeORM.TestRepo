using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.ZzzTest_WFA2.Source.DL
{
    public class GradesDL : BaseDL
    {
        public GradesDL()
            : base()
        {
        }
        public GradesDL(string connName)
            : base(connName)
        {
        }
    }
}
