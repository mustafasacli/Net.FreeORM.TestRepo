namespace Net.FreeORM.ZZZ_TestAppWFA.Source.QO
{
    /* Query Object Class */
    public class Crud
    {
    }
}
