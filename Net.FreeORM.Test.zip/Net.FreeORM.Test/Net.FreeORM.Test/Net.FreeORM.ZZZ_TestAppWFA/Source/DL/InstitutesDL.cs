using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.ZZZ_TestAppWFA.Source.DL
{
	public class InstitutesDL : BaseDL
	{
		public InstitutesDL()
			: base()
		{
		}
	}
}
