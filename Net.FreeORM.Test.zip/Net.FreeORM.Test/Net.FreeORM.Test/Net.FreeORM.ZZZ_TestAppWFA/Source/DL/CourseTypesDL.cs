using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.ZZZ_TestAppWFA.Source.DL
{
	public class CourseTypesDL : BaseDL
	{
		public CourseTypesDL()
			: base()
		{
		}
	}
}
