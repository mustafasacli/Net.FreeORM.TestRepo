using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.ZZZ_TestAppWFA.Source.DL
{
	public class UserRoleDL : BaseDL
	{
		public UserRoleDL()
			: base()
		{
		}
	}
}
