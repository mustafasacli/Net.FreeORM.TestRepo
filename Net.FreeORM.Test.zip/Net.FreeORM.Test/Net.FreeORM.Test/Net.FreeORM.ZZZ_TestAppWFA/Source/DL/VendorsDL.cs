using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.ZZZ_TestAppWFA.Source.DL
{
	public class VendorsDL : BaseDL
	{
		public VendorsDL()
			: base()
		{
		}
	}
}
