using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.ZZZ_TestAppWFA.Source.DL
{
	public class OperationsDL : BaseDL
	{
		public OperationsDL()
			: base()
		{
		}
	}
}
