using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.ZZZ_TestAppWFA.Source.DL
{
	public class RolesDL : BaseDL
	{
		public RolesDL()
			: base()
		{
		}
	}
}
