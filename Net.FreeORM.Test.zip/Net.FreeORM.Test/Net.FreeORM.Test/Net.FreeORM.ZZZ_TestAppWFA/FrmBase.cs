﻿namespace Net.FreeORM.ZZZ_TestAppWFA
{
    public class FrmBase : System.Windows.Forms.Form
    {

        public FrmBase()
            : base()
        {
            this.SuspendLayout();
            //
            //
            //
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "FrmBase";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

    }
}
