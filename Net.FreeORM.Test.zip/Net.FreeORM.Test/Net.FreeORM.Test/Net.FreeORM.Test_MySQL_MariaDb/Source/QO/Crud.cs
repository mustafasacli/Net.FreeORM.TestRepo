namespace Net.FreeORM.Test_MySQL_MariaDb.Source.QO
{
    /* Query Object Class */
    public class Crud
    {
    }
}
