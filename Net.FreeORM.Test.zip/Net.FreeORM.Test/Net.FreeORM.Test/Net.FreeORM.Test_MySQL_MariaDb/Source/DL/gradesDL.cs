using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.Test_MySQL_MariaDb.Source.DL
{
    public class gradesDL : MainDL
    {
        public gradesDL()
            : base()
        {
        }
    }
}
