﻿using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.Test_MySQL_MariaDb.Source.DL
{
    public class MainDL : BaseDL
    {
        public MainDL()
            : base("main4")
        { }

    }
}
