using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.Test_PostgreSQL.Source.DL
{
    public class FreeLogEntryDL : BaseDL
    {
        public FreeLogEntryDL()
            : base()
        {
        }
    }
}
