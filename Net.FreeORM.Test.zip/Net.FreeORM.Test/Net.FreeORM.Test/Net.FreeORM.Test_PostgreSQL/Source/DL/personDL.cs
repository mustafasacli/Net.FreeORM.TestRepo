using System;
using Net.FreeORM.Framework.BaseDal;

namespace Net.FreeORM.Test_PostgreSQL.Source.DL
{
    public class personDL : BaseDL
    {
        public personDL()
            : base()
        {
        }
    }
}
