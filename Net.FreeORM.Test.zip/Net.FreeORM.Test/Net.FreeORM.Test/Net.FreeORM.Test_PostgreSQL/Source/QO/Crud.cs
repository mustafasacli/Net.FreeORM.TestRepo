namespace Net.FreeORM.Test_PostgreSQL.Source.QO
{
    /* Query Object Class */
    public class Crud
    {
    }
}