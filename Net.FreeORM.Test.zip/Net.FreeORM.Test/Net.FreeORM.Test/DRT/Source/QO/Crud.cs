namespace DRT.Source.QO
{
    /* Query Object Class */

    public class Crud
    {
    }
}