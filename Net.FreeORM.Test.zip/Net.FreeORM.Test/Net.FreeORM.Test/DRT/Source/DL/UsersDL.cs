using System;
using Net.FreeORM.Framework.BaseDal;

namespace DRT.Source.DL
{
    public class UsersDL : BaseDL
    {
        public UsersDL()
            : base("main")
        {
        }
    }
}
