using System;
using Net.FreeORM.Framework.BaseDal;

namespace DRT.Source.DL
{
	public class FreeLogEntryDL : BaseDL
	{
		public FreeLogEntryDL()
			: base()
		{
		}
	}
}
